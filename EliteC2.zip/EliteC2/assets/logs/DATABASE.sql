-- MySQL dump 10.13  Distrib 8.0.39, for Linux (x86_64)
--
-- Host: localhost    Database: db834674
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT '',
  `host` varchar(255) DEFAULT '',
  `port` int DEFAULT '0',
  `duration` int DEFAULT '0',
  `method` varchar(255) DEFAULT '',
  `method_group` varchar(255) DEFAULT '',
  `time_sent` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` VALUES (1,'root','70.70.70.1',53,30,'udp','main network',1727954249),(2,'root','70.70.70.1',53,30,'udp','main network',1727954311),(3,'root','70.70.70.1',53,30,'udp','main network',1727954513),(4,'root','70.70.70.1',53,30,'udp','main network',1727954622),(5,'root','70.70.70.1',53,30,'udp','main network',1727954718),(6,'root','70.70.70.1',53,30,'udp','main network',1727954742),(7,'root','70.70.70.1',53,30,'udp','main network',1727954830),(8,'root','70.70.70.1',53,30,'udp','main network',1727954938),(9,'root','70.70.70.1',53,30,'udp','main network',1727954956),(10,'root','70.70.70.1',53,30,'udp-hurt','main network',1727957477);
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT '',
  `password` varchar(255) DEFAULT '',
  `vip` int DEFAULT '0',
  `reseller` int DEFAULT '0',
  `mod` int DEFAULT '0',
  `admin` int DEFAULT '0',
  `roles` varchar(255) DEFAULT '',
  `api` int DEFAULT '0',
  `bypass_power_saving` int DEFAULT '0',
  `bypass_spam_protection` int DEFAULT '0',
  `bypass_blacklist` int DEFAULT '0',
  `bypass_soft_max_time` int DEFAULT '0',
  `telegram_id` int DEFAULT '0',
  `theme` varchar(255) DEFAULT '',
  `max_daily_attacks` int DEFAULT '0',
  `cooldown` int DEFAULT '0',
  `max_time` int DEFAULT '0',
  `concurrents` int DEFAULT '0',
  `banned` varchar(255) DEFAULT '',
  `locked` int DEFAULT '0',
  `mfa` varchar(255) DEFAULT '',
  `time_redeemed` int DEFAULT '0',
  `created_by` varchar(255) DEFAULT '',
  `time_created` int DEFAULT '0',
  `plan_length` int DEFAULT '0',
  `unix_expiry` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'root','49d35acd09734afec6378b34cb3d698596f59beab19976399e573491358c06d1',0,1,1,1,'',1,1,1,1,1,0,'default',1000,0,9999,9999,'',0,'',1727954168,'system',0,999,1814267768);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-03 14:16:14
